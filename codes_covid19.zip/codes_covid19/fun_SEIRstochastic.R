## Simulation based on stochastic SEIR model
## five periods: Jan 1-9, Jan 10-22, Jan 23-Feb 1, Feb 2-16, Feb 17-
#' @param init_obs                a vetor of initial states c(S = S0, E = E0, I = I0, R = R0, H = H0, A = A0)
#' @param times                   the time period to simulate,for example, 1:68 means from Jan 1 to Mar 8
#' @param pars                    a vetor of pars: c(b12, b3, b3, b5, r12, r3, r4, r4)
#' @param fix_pars                pars are the same for the five periods, c(a, De, Di, Dh, N)
#' @param a                       ratio of transmission rates of unascertained cases over ascertained cases
#' @param De                      latent period
#' @param Di                      infectious period
#' @param Dh                      hospitalization period
#' @param N                       population size
#' @param stage_pars              pars are  different for the different periods, c(b, r, Dq, n)
#' @param b                       transmission rate of ascertained cases
#' @param r                       ascertainment rate  
#' @param Dq                      duration from illness onset to hospitalization
#' @param n                       daily inbound and outbound size
fun_seir <- function(init_obs, times, pars) {
  ## mysample function
  mysample <- function(stage_pars, fix_pars, old_values) {
    ## stage pars
    b <- stage_pars[1]
    r <- stage_pars[2]
    Dq <- stage_pars[3]
    n <- stage_pars[4]
    ## fixed pars
    a <- fix_pars[1]
    De <- fix_pars[2]
    Di <- fix_pars[3]
    Dh <- fix_pars[4]
    N <- fix_pars[5]
    ## old values
    S <- old_values[1]
    E <- old_values[2]
    I <- old_values[3]
    R <- old_values[4]
    H <- old_values[5]
    A <- old_values[6]
    N1 <- S+E+A+R
    ##
    pS_vec <- c(b * (I + a * A) / N, n / N1, 1 - b * (I + a * A) / N - n / N1)
    sample_S <- rmultinom(1, size = S, prob = pS_vec)
    ##
    pE_vec <- c(r / De, (1-r) / De, n / N1, 1 - 1 / De - n / N1)
    sample_E <- rmultinom(1, size = E, prob = pE_vec)
    ##
    pI_vec <- c(1 / Dq, 1 / Di, 1 - 1 / Dq - 1 / Di)
    if((1 / Dq + 1 / Di) > 1) {
      pI_vec <- c(1 / Dq, 1 - 1 / Dq, 0)
    }
    sample_I <- rmultinom(1, size = I, prob = pI_vec)
    ##
    pA_vec <- c(1 / Di, n / N1, 1 - 1 / Di - n / N1)
    sample_A <- rmultinom(1, size = A, prob = pA_vec)
    ##
    pH_vec <- c(1 / Dh, 1 - 1 / Dh)
    sample_H <- rmultinom(1, size = H, prob = pH_vec)
    ##
    pR_vec <- c(n / N1, 1 - n / N1)
    sample_R <- rmultinom(1, size = R, prob = pR_vec)
    ## new values
    S_new <- sample_S[3] + n
    E_new <- sample_E[4] + sample_S[1]
    I_new <- sample_I[3] + sample_E[1]
    R_new <- sample_R[2] + sample_I[2] + sample_A[1] + sample_H[1]
    H_new <- sample_H[2] + sample_I[1]
    A_new <- sample_A[3] + sample_E[2]
    estN_new <- sample_E[1]
    ##
    return(c(S_new, E_new, I_new, R_new, H_new, A_new, estN_new))
  }
  ## matrix for save the results
  ymat <- matrix(0, length(times), length(init_obs) + 2)
  ymat[, 1] <- times
  colnames(ymat) <- c("time", names(init_obs), "estN")
  ## fixed pars
  myfix_pars <- c(a = 1, De = 5.2, Di = 2.3,Dh = 30, N = 10000000)
  ## stage 1
  mystage_pars <- c(b = pars[1], r = pars[5], Dq = 21/2, n = 500000)
  for(i in 1:9) {  
    if(i == 1) {
      myold_values <- init_obs
    } else {
      myold_values <- ymat[i - 1, 2:7]
    }
    ymat[i, 2:8] <- mysample(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  ## stage 2
  mystage_pars <- c(b = pars[1], r = pars[5], Dq = 15/2, n = 800000)
  for(i in 10:22) { 
    myold_values <- ymat[i - 1, 2:7]
    ymat[i, 2:8] <- mysample(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  ## stage 3
  mystage_pars <- c(b = pars[2], r = pars[6], Dq = 10/2, n = 0)
  for(i in 23:32) {
    myold_values <- ymat[i - 1, 2:7]
    ymat[i, 2:8] <- mysample(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  ## stage 4
  mystage_pars <- c(b = pars[3], r = pars[7], Dq = 6/2, n = 0)
  for(i in 33:47) {
    myold_values <- ymat[i - 1, 2:7]
    ymat[i, 2:8] <- mysample(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  ## stage 5
  mystage_pars <- c(b = pars[4], r = pars[8], Dq = 2/2, n = 0)
  for(i in 48:length(times)) {
    myold_values <- ymat[i - 1, 2:7]
    ymat[i, 2:8] <- mysample(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  return(ymat)
}
