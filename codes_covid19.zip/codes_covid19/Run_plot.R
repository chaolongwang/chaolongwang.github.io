## estimates of the pars c(b12, b3, b3, b5, r12, r3, r4, r4)
mcmc_pars_estimate <- read.table("Results_mcmc_pars.txt", header = T)
fgname <- colnames(mcmc_pars_estimate)

png("figure.trace.png", width = 3000, height = 2000, res = 300)
par(mfrow=c(2, 4))
par(mar = c(4, 4, 1, 1))
for(i in 1:8) {
  plot(1:nrow(mcmc_pars_estimate), mcmc_pars_estimate[, i], xlab = "iter", ylab = fgname[i], main="", type="l", cex = 0.1, pch = 20, col = "red")
}
dev.off()
##
png("figure.hist.png", width = 3000, height = 2000, res = 300)
par(mfrow=c(2, 4))
par(mar = c(4, 4, 1, 1))
for(i in 1:8) {
  hist(mcmc_pars_estimate[, i], xlab = fgname[i], main = "")
}
dev.off()


