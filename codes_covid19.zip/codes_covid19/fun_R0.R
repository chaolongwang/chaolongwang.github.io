## Ro for the five period
## five periods: Jan 1-9, Jan 10-22, Jan 23-Feb 1, Feb 2-16, Feb 17-
#' @param predat                  data frame of the prediction (time, S, E, I, R, H, A, estN) using fun_seir/fun_pred
#' @param estpar                  estimates of the parameters (b12, b3, b3, b5, r12, r3, r4, r5)
#' @param Di                      infectious period
#' @param b                       transmission rate of ascertained cases
#' @param r                       ascertainment rate
fun_R0 <- function(predat, estpar) {
  Di <- 2.3 
  predA <- predat[1:68, "A"]
  predI <- predat[1:68, "I"]
  ## 1.1 - 1.9
  A <- predA[1:9]
  I <- predI[1:9]
  Dq <- 21 / 2  ## half, based on NEJM
  b <- estpar[1]
  r <- estpar[5]
  R01 <- (1 - r) * b * Di  +  r * b * Di * (Dq / (Di + Dq))
  ## 1.10 - 1.22
  A <- predA[10:22]
  I <- predI[10:22]
  Dq <- 15 / 2 
  b <- estpar[1]
  r <- estpar[5]
  R02 <- (1 - r) * b * Di  +  r * b * Di * (Dq / (Di + Dq))
  ## 1.23 - 2.1
  A <- predA[23:32]
  I <- predI[23:32]
  Dq <- 10 / 2 
  b <- estpar[2]
  r <- estpar[6]
  R03 <- (1 - r) * b * Di  +  r * b * Di * (Dq / (Di + Dq))
  # 2.2 - 2.16
  A <- predA[33:47]
  I <- predI[33:47]
  Dq <- 6 / 2 
  b <- estpar[3]
  r <- estpar[7]
  R04 <- (1 - r) * b * Di  +  r * b * Di * (Dq / (Di + Dq))
  #
  # 2.17 - 3.8
  A <- predA[48:68]
  I <- predI[48:68]
  Dq <- 2 / 2 
  b <- estpar[4]
  r <- estpar[8]
  R05 <- (1 - r) * b * Di  +  r * b * Di * (Dq / (Di + Dq))
  #
  R0 <- c(mean(R01), mean(R02), mean(R03), mean(R04), mean(R05))
  return(R0)
}