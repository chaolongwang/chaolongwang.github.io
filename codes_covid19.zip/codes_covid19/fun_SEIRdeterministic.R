## Simulation based on deterministic SEIR model
## five periods: Jan 1-9, Jan 10-22, Jan 23-Feb 1, Feb 2-16, Feb 17-
#' @param init_obs                a vetor of initial states c(S = S0, E = E0, I = I0, R = R0, H = H0, A = A0)
#' @param times                   the time period to simulate,for example, 1:68 means from Jan 1 to Mar 8
#' @param pars                    a vetor of pars: c(b12, b3, b3, b5, r12, r3, r4, r4)
#' @param fix_pars                pars are the same for the five periods, c(a, De, Di, Dh, N)
#' @param a                       ratio of transmission rates of unascertained cases over ascertained cases
#' @param De                      latent period
#' @param Di                      infectious period
#' @param Dh                      hospitalization period
#' @param N                       population size
#' @param stage_pars              pars are different for the different periods, c(b, r, Dq, n)
#' @param b                       transmission rate of ascertained cases
#' @param r                       ascertainment rate  
#' @param Dq                      duration from illness onset to hospitalization
#' @param n                       daily inbound and outbound size
fun_pred <- function(init_obs, times, pars) {
  ## myode function
  myode <- function(stage_pars, fix_pars, old_values) {
    ## stage pars
    b <- stage_pars[1]
    r <- stage_pars[2]
    Dq <- stage_pars[3]
    n <- stage_pars[4]
    ## fixed pars
    a <- fix_pars[1]
    De <- fix_pars[2]
    Di <- fix_pars[3]
    Dh <- fix_pars[4]
    N <- fix_pars[5]
    ## old values
    S <- old_values[1]
    E <- old_values[2]
    I <- old_values[3]
    R <- old_values[4]
    H <- old_values[5]
    A <- old_values[6]
    N1 <- S+E+A+R
    ## new values
    S_new <- S - b * S * (I + a * A) / N + n - n * S / N1
    E_new <- E + b * S * (I + a * A) / N - E / De - n * E / N1
    I_new <- I + E * r / De  - I / Dq - I / Di
    R_new <- R + (A + I) / Di  + H / Dh - n * R / N1
    H_new <- H + I / Dq - H / Dh
    A_new <- A + E * (1 - r) / De - A / Di - n * A / N1
    estN_new <- E * r / De
    ##
    return(c(S_new, E_new, I_new, R_new, H_new, A_new, estN_new))
  }
  ## matrix for save the results
  ymat <- matrix(0, length(times), length(init_obs) + 2)
  ymat[, 1] <- times
  colnames(ymat) <- c("time", names(init_obs), "estN")
  ## fixed pars
  myfix_pars <- c(a = 1, De = 5.2, Di = 2.3, Dh = 30, N = 10000000)
  ## stage 1
  mystage_pars <- c(b = pars[1], r = pars[5], Dq = 21/2, n = 500000)
  for(i in 1:9) {  
    if(i == 1) {
      myold_values <- init_obs
    } else {
      myold_values <- ymat[i - 1, 2:7]
    }
    ymat[i, 2:8] <- myode(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  ## stage 2
  mystage_pars <- c(b = pars[1], r = pars[5], Dq = 15/2, n = 800000)
  for(i in 10:22) { 
    myold_values <- ymat[i - 1, 2:7]
    ymat[i, 2:8] <- myode(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  ## stage 3
  mystage_pars <- c(b = pars[2], r = pars[6], Dq = 10/2, n = 0)
  for(i in 23:32) {
    myold_values <- ymat[i - 1, 2:7]
    ymat[i, 2:8] <- myode(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  ## stage 4
  mystage_pars <- c(b = pars[3], r = pars[7], Dq = 6/2, n = 0)
  for(i in 33:47) {
    myold_values <- ymat[i - 1, 2:7]
    ymat[i, 2:8] <- myode(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  ## stage 5
  mystage_pars <- c(b = pars[4], r = pars[8], Dq = 2/2, n = 0)
  for(i in 48:length(times)) {
    myold_values <- ymat[i - 1, 2:7]
    ymat[i, 2:8] <- myode(stage_pars = mystage_pars, fix_pars = myfix_pars, old_values = myold_values)
  }
  return(ymat)
}