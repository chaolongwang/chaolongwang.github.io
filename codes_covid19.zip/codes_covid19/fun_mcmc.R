## mcmc using the Metropolis-Hastings algorithm
#' @param init_pars               initial parameters c(b12, b3, b3, b5, r12, r3, r4, r5)
#' @param step_pars               a vector of sd of the parameter moving steps
#' @param init_state_num          a vetor of initial states c(S = S0, E = E0, I = I0, R = R0, H = H0, A = A0)
#' @param observed_num            case numbers with onset date from Jan 1 to Feb 29
#' @param niter                   number of mcmc iterations after burn in
#' @param BurnIn                  number of mcmc iterations for burn in
#' @param trace_num               step size of mcmc              
#' @param runMLE                  whether run MLE to provide initial values of the parameters
fun_mcmc <- function(init_pars, step_pars, init_state_num, observed_num, niter = 1000000, BurnIn = 200000, trace_num = 100, runMLE = T){
  ## use mle to set the initial pars for mcmc
  if(runMLE) {
    mle_optim <- fun_mle(init_pars = init_pars, init_state_num = init_state_num, observed_num = observed_num, opt_num = 3)
    mle_pars <- mle_optim
    init_pars <- mle_pars[3:10]
    cat("The MLE estimates: ", round(init_pars, digits=4), fill = T)
  } else {
    mle_pars <- NULL
    init_pars <- init_pars
  }
  
  ## function for pars
  ## pars = c(b12, b3, b3, b5, r12, r3, r4, r5)
  Prior_func <- function(pars){
	if(any(pars < 0) || any(pars[5:8] > 1)){
      return (0)
    }else{
      return (1) ## Set a non-informative prior
    }
  }
  ## function for log likelihood
  LL_func <- function(pars){
    ypred <- fun_pred(init_obs = init_state_num, times = ftime, pars = pars)
    ypred <- ypred[, 8]
    try(p <- dpois(observed_num, ypred), silent = T)
    if(any(p == 0) || any(is.nan(p))){
      logL <- -Inf
    }else{
      logL <- sum(log10(p))
    }
    return(logL)
  }
  ## R0 estimation
  ftime <- 1:length(observed_num)
  predat <- fun_seir(init_obs = init_state_num, times = 1:68, pars = init_pars)
  R0_est <- fun_R0(predat, estpar = init_pars)
  ## buil the matrix to store the results
  np <- length(init_pars)
  pmat <- matrix(0, ((niter + BurnIn) / trace_num) + 1, np+5) ## parameters + R0 for five periods
  colnames(pmat) <- c("b12", "b3", "b4", "b5", "r12", "r3", "r4", "r5", "R01", "R02", "R03", "R04", "R05")
  pmat[1, 1:np] <- init_pars
  pmat[1, (np+1):(np+5)] <- R0_est
  rm(R0_est, predat)
  ##
  pars_now <- init_pars
  
  cat("MCMC:", fill = T) 
  for(i in 2:(niter + BurnIn)){
    #pars_now <- pmat[i-1, ]
    #pars_new <- rep(0, np)
    pars_new <- rep(0, np)
    for(j in 1:np){
      pars_new[j] <- rnorm(1, mean = pars_now[j], sd = step_pars[j])
    }
    A <- 0
    if(Prior_func(pars_new) > 0){ 
      ll_pars_new <- LL_func(pars = pars_new)
      if(ll_pars_new != -Inf) {
        ll_pars_now <- LL_func(pars = pars_now)
        A <-  10^(ll_pars_new - ll_pars_now) # Prior_func(pars_new) / Prior_func(pars_now) * 10^(ll_pars_new - ll_pars_now)
      }else{
        cat(i, " logL =", ll_pars_new, fill = T) 
      }
    }
    
    if(runif(1) < A){
      pars_now <- pars_new
    }
    if(i %% trace_num == 0) {
      predat <- fun_seir(init_obs = init_state_num, times = 1:68, pars = pars_now)
      R0_est <- fun_R0(predat, estpar = pars_now)
      pmat[(i / trace_num) + 1, 1:np] <- pars_now
      pmat[(i / trace_num) + 1, (np+1):(np+5)] <- R0_est
      rm(R0_est, predat)
    }
    if(i%%10000 == 0) cat("Iter", i, " A =", round(A, digits=5), " : ", round(pars_now, digits=4), fill = T)
    
  }
  est_list <- list(mle_estimates = mle_pars, mcmc_estimates = pmat[-c(1:(BurnIn / trace_num + 1)), ])
  ## print output
  mcmc_estimates = pmat[-c(1:(BurnIn / trace_num + 1)), ]
  cat("########################   Brief Summary    #####################################", fill = T)
  cat("##          b12   b3   b4   b5   r12   r3   r4   r5   R01   R02   R03   R04   R05", fill = T)
  cat("##  Mean :", round(apply(mcmc_estimates, 2, mean), 3), fill = T)
  cat("##  2.5% :", round(apply(mcmc_estimates, 2, function(x) quantile(x, 0.025)), 3), fill = T)
  cat("## 97.5% :", round(apply(mcmc_estimates, 2, function(x) quantile(x, 0.975)), 3), fill = T)
  cat("###############################   Done    ########################################", fill = T)
  return(est_list)
} 

