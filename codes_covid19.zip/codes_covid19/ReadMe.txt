# This folder includes the data and codes for reporducing the results in the manuscript:
# "Full-spectrum dynamics of the coronavirus disease outbreak in Wuhan, China: a modeling study of 32,583 laboratory-confirmed cases"
# Authors: Xingjie Hao, Shanshan Cheng, Degang Wu, Tangchun Wu, Xihong Lin, Chaolong Wang

###### Data  ######

Covid19CasesWH.csv             
# This file contains daily counts of laboratory-confirmed cases with onset between Dec 8, 2019 and Mar 8, 2020
# Detailed description of the data can also be found in the following paper:
# Association of public health interventions with the epidemiology of the COVID-19 outbreak in Wuhan, China. JAMA, 2020, doi: 10.1001/jama.2020.6130.
# Note on 2020/4/25: This file will be available once data release permission is granted. 


SimuDailyOnset.csv
# This file contains simulated daily case counts from Jan 1, 2020 and Mar 8, 2020. 
# The simulation is based on the stochastsic model described in our paper, with parameters estimated from real data.
# This file is for the purpose of testing codes.


##### R Codes  #####
# The R codes below can be used to reporduce the SEIR model described in our paper.

## Analysis scripts ##
# You can run the following scripts to obtain results 

Run_SEIR.R                     # This script will perform parameter estimation based on the main model described in the paper
Run_plot.R                     # This script will plot the histograms and trace plots of MCMC results
Run_outbreakSimu.R             # This script will perform outbreak simulation to prediction of resurge after lifting controls

## Functions ##
# The analysis scripts depend on the following R functions
 
fun_mcmc.R                     # Parameter estimation using MCMC
fun_mle.R                      # Parameter estimation using MLE
fun_SEIRstochastic.R           # SEIR simulation based on stochastic model
fun_SEIRdeterministic.R        # SEIR simulation based on deterministic model
fun_R0.R                       # Estimation of R0 for five periods
outbreakSimu1.R                # Outbreak simulation assuming controls are lifted at day t after the first day of zero ascertained cases 
outbreakSimu2.R                # Outbreak simulation assuming controls are lifted after observing zero ascertained cases for t days consecutively


## Outputs ##
# Example outputs are provided in the folder "outputs", which includes the following files.

Covid19inWH.par.est.txt        # Parameter estimation from MCMC
outbreaksimu1.t14.txt          # Prediction of resurge date by simulations assuming controls are lifted at day t=14 after the first day of zero ascertained cases 
outbreaksimu2.t14.txt          # Prediction of resurge date by simulations assuming controls are lifted after observing zero ascertained cases for t=14 days consecutively 
figure.hist.png                # Histogram plot of parameter estimates by MCMC
figure.trace.png               # Trace plot of parameter estimates by MCMC