# Function to numerically obtain MLE estimates of the parameters
#' @param init_pars               initial parameters (b12, b3, b4, b5, r12, r3, r4, r5)
#' @param init_state_num          a vetor of initial states c(S = S0, E = E0, I = I0, R = R0, H = H0, A = A0)
#' @param observed_num            number of onset from Jan 1 to Feb 29
#' @param opt_num                 number of MLE optimization
fun_mle <- function(init_pars, init_state_num, observed_num, opt_num) {
  ## negtive likelihood
  ## parinit <- (b12, b3, b4, b5, r12, r3, r4, r5)
  ftime <- 1:length(observed_num)
  negLL_func <- function(pars){
    ypred <- fun_pred(init_obs = init_state_num, times = ftime, pars = pars)
    ypred <- ypred[, 8]
    try(p <- dpois(observed_num, ypred), silent = T)
    if(any(p == 0) || any(is.nan(p))){
      logL <- -Inf
    }else{
      logL <- sum(log10(p))
    }
    return(-logL)
  }
  result_mat <- matrix(NA, opt_num, length(init_pars) * 2 + 2)
  colnames(result_mat) <- c("likelihood", "convergence", "b12", "b3", "b4", "b5", "r12", "r3", "r4", "r5", "b12_sd", "b3_sd", "b5_sd", "b3_sd", "r12_sd", "r3_sd", "r4_sd", "r5_sd")
  result_mat[, 1] <- -Inf
  for(i in 1:opt_num) {
    passed <- FALSE
    while (!passed) {
      try(mle_opt <- optim(init_pars, negLL_func, method = "SANN", hessian = T), silent = T)
      passed <- exists("mle_opt")
    }
    result_mat[i, 1] <- -mle_opt$value
    result_mat[i, 2] <- mle_opt$convergence
    result_mat[i, 3:10] <- mle_opt$par
    result_mat[i, 11:18] <- sqrt(diag(solve(mle_opt$hessian)))
    cat(i, "MLE run finished!", fill = T)
    rm(mle_opt)
  }
  result <- result_mat[which(result_mat[, 1] == max(result_mat[, 1])), ]
  return(result)
}
