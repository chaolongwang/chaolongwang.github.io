# initial states c(S = S0, E = E0, I = I0, R = R0, H = H0, A = A0)
yinit <- c(S = 9999427, E = 370, I = 88, R = 0, H = 27, A = 88)
## estimates of the pars c(b12, b3, b3, b5, r12, r3, r4, r4)
mcmc_pars_estimate <- read.table("Results_mcmc_pars.txt", header = T)


## simulation 1: simulate outbreak when lifting all control measures at least sim_t days of zero ascertained cases
source("outbreakSimu1.R")
sim_t <- 14
## we assume resurge will happen in one year. If estdate == NA, no resurge will happen in one year 
estdate <- apply(mcmc_pars_estimate[1:10000, 1:8], 1, function(x) fun_seir(init_obs = yinit, freeday = sim_t, pars = x))

## probility of resurge
P <- length(na.omit(estdate)) / length(estdate)
cat("Probability of resurge for scenario 1: ", P, fill = T)
cat("Resurge date: ", fill = T)
## summary of resurge time
print(summary(na.omit(estdate)))
## save the results
write.table(estdate, "outbreaksimu1.t14.txt", quote = F, row.names = F, col.names = F)
## 


## simulation 2: simulate outbreak when lifting all control measures sim_t days after the first day of zero ascertained cases 
source("outbreakSimu2.R")
sim_t <- 14
## we assume resurge will happen in one year. If estdate == NA, no resurge will happen in one year
estdate <- apply(mcmc_pars_estimate[1:10000, 1:8], 1, function(x) fun_seir(init_obs = yinit, freeday = sim_t, pars = x))

## probility of resurge
P <- length(na.omit(estdate)) / length(estdate)
cat("Probability of resurge for scenario 2: ", P, fill = T)
cat("Resurge date: ", fill = T)
## summary of resurge time
print(summary(na.omit(estdate)))
## save the results
write.table(estdate, "outbreaksimu2.t14.txt", quote = F, row.names = F, col.names = F)



