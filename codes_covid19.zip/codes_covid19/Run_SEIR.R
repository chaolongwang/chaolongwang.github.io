source("fun_mle.R")
source("fun_mcmc.R")
source("fun_R0.R")
source("fun_SEIRstochastic.R")
source("fun_SEIRdeterministic.R")

## Real Data 
#rdat <- read.csv("Covid19CasesWH.csv")
#rdat <- rdat[-c(1:23), ]
rdat <- read.csv("SimuDailyOnset.csv")
 
#cases from Jan 1 to Feb 29
obsN <- rdat[, 2]
  
#population size
N <- 10000000 

#initial number of hospitalized cases based on the reports
H0 <- 27

#initial number of ascertained infectious cases
I0 <- 88

#initial number of unascertained infectious cases
propA0 <- 1   
A0 <- I0 * propA0

#initial number of latent cases, De=5.3
E0 <- (300 - 115) * (1 + propA0)

#initial number of removed individuals
R0 <- 0

#initial number of susceptible individuals
S0 <- N - E0 - I0 - A0 - H0 - R0

# initial states c(S = S0, E = E0, I = I0, R = R0, H = H0, A = A0)
yinit <- c(S = S0, E = E0, I = I0, R = R0, H = H0, A = A0)

## MCMC parameters estimatation
## initial parameters c(b12, b3, b3, b5, r12, r3, r4, r5)
pars_start <- c(1.6, 0.6, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2)  

# Run MCMC for parameter estimation
pars_estimate <- fun_mcmc(init_pars = pars_start, step_pars = pars_start / 100, init_state_num = yinit, observed_num = obsN, niter = 1000000, BurnIn = 200000, trace_num = 100, runMLE = T)

mcmc_pars_estimate <- round(pars_estimate$mcmc_estimates, 3)
write.table(mcmc_pars_estimate, "Results_mcmc_pars.txt", quote = F, row.names = F, sep = "\t")
